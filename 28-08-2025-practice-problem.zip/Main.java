 //day 2 
 
  //daimond star
  
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for( int row=1;row<=n;row++){
            for( int col=1;col<=n-row;col++)
             System.out.print(" ");
            for( int col=1;col<=2*row-1;col++)
             System.out.print("*");
             System.out.println();
        }
         for( int row=n-1;row>=1;row--){
            for( int col=1;col<=n-row;col++)
             System.out.print(" ");
             for( int col=1;col<=2*row-1;col++)
             System.out.print("*");
             System.out.println();
        }    
    }
}*/ 

  // x star
  
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for( int row=1;row<=n;row++){
            for( int col=1;col<=row;col++)
              System.out.print("*");
              for( int col=1;col<=2*(n-row);col++)
              System.out.print(" ");
              for( int col=1;col<=row;col++)
              System.out.print("*");
             System.out.println(" ");
        }
        for( int row=n-1;row>=1;row--){
            for( int col=1;col<=row;col++)
              System.out.print("*");
              for( int col=1;col<=2*(n-row);col++)
              System.out.print(" ");
              for( int col=1;col<=row;col++)
              System.out.print("*");
             System.out.println(" ");
        }
	}
}*/

 // count numbers
 
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int count=0;
        while(n>0){
            n=n/10;
            count++;
            System.out.println(count);
      
        }
	}
}*/

 // input as output
 
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int temp=n;
        int count=0;
        while(n>0){
            n=n/10;
            count++;
        }
            int num=(int)Math.pow(10,count-1);
      while(num>0){
          int dig=(temp/num)%10;
          System.out.print(dig+" ");
          num=num/10;
      }
        
	}
}*/

 // hallow square star
 
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for (int i=1; i<n; i++){
            for (int j=1; j<n; j++){
                if(i == 1 || i == n-1 || j == 1 || j == n-1)
                System.out.print("*");
                else
                System.out.print(" ");
            }
            System.out.println();
        }
	}
}*/

 // equlaterl triangle
 
/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for (int i=1; i<=n; i++){
            for(int k=1; k<=n-i; k++){
                System.out.print(" ");
            }
            for (int j=1; j<=2*i-1; j++){
                System.out.print("*");
            }
            System.out.println();
        }
	}
}*/