  //even or odd
  
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if(n%2==0){
            System.out.println("even");
        }else{
            System.out.println("odd");
        }
	}
}*/

  //pos or neg or zero
  
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if(n>0){
            System.out.println("positive");
        }else if(n<0){
            System.out.println("negative");
        }else{
            System.out.println("zero");
        }    
	}
}*/

   //num/both 3&5

/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if(n%3==0 && n%5==0){
         System.out.println("yes");
         }else{
         System.out.println("no");
        }
	}
}*/

   //year month day 

/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int d = scan.nextInt();
        if (d >= 365) {
             int y = d / 365;
             d = d % 365;
             System.out.println("years:" +y);
        }else if (d >= 30); {
             int m = d/ 30;
              d = d % 30;
               System.out.println("months:" +m);
        }
        if(d>0){
               System.out.println("days:" +d);
        } 
	}
}*/	

    // print min &max
  
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n1 = scan.nextInt();
        int n2 = scan.nextInt();
        if(n1>n2){
            System.out.println("min="+ n1);
            System.out.println("max="+ n2);
        }else{
            System.out.println("min="+ n1);
            System.out.println("max="+ n2);
        }
	}
}*/	
	
	// Max of 3 Numbers 
	
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n1 = scan.nextInt();
        int n2 = scan.nextInt();
        int n3 = scan.nextInt();
        if(n1>n2){
            System.out.println("max="+ n1);
        }else if(n2>n3){
            System.out.println("max="+ n2);
        }else{
            System.out.println("max="+ n3);
        }
        
        
	}
}*/

   // Positive, Negative or Zero
	
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if(n>0){
            System.out.println(n+ " is positive");
        }else if(n<0){
            System.out.println(n+ " is negative");
        }else{
            System.out.println(n+ " is zero");
        }    
	}
}*/

 //Mileage Remuneration Calculator 
 
/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        double start = scan.nextDouble();	
        double end = scan.nextDouble();
	    double distance = end - start;
	    double remuneration = distance * 25;
         System.out.printf("%.2f %.2f", distance, remuneration);
	}
}*/	
	
	//customer grouping
	
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int age = scan.nextInt();     
        int gender = scan.nextInt();  
        if (gender == 1) {  
            if (age < 25) {
                System.out.println("Group 1");
            } else if (age <= 45) {
                System.out.println("Group 3");
            } else {
                System.out.println("Group 5");
            }
        } else if (gender == 2) {  
            if (age < 25) {
                System.out.println("Group 2");
            } else if (age <= 45) {
                System.out.println("Group 4");
            } else {
                System.out.println("Group 5");
            }
        } else {
            System.out.println("Invalid");
        }
    }
}*/

  // SBI Credit Card Eligibility
	
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int primaryAge = scan.nextInt();    
        int addonAge = scan.nextInt();      
        int empType = scan.nextInt();       
        int income = scan.nextInt();        
        if (primaryAge >= 21 && primaryAge <= 60 &&
            addonAge > 18 &&
            (empType == 1 || empType == 2 || empType == 3 || empType == 4) &&
            income <= 300000) {
            System.out.println("Yes. You are eligible for SBI credit cards");
        } else {
            System.out.println("No. You are not eligible for SBI credit cards");
        }
    }
}*/
	
  // Triangle Shape

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        int c = scan.nextInt();
        if (a == b && b == c) {
            System.out.println("Equilateral Triangle");
        } else if (a == b || b == c || a == c) {
            System.out.println("Isosceles Triangle");
        } else {
            System.out.println("Scalene Triangle");
        }
    }
}*/

// Descending Order of 4 Numbers         

/*import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int[] numbers = new int[4];
        for (int i = 0; i < 4; i++) {
            numbers[i] = scan.nextInt();
        }
        Arrays.sort(numbers);
        for (int i = 3; i >= 0; i--) {
            System.out.print(numbers[i] + " ");
        }
    }
}*/

  //Character Type
  
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        char ch = scan.next().charAt(0);
        if (Character.isLetter(ch)) {
            System.out.println("alphabet");
        } else if (Character.isDigit(ch)) {
            System.out.println("digit");
        } else {
            System.out.println("special");
        }
    }
}*/

  //Even Numbers in Range 

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int start = scan.nextInt();
        int end = scan.nextInt();
        for (int i = start; i <= end; i++) {
            if (i % 2 == 0) {   
                 System.out.print(i + " ");
            }
        }
    }
}*/
   //Sum of Even Numbers

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0) {   
                sum = sum + i;
            }
        }
        System.out.println(sum);
    }
}*/

    //Sum of Odd and Even Numbers 

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int sumOdd = 0, sumEven = 0;
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0) {     
                sumEven += i;
            } else {              
                sumOdd += i;
            }
        }
        System.out.println(sumOdd + " " + sumEven);
    }
}*/

    // Factorial 

/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        if (n > 0) {
            long fact = 1;   
            for (int i = 1; i <= n; i++) {
                fact = fact * i;
                System.out.println(fact);
            }    
        }else{
               System.out.println("Error! Factorial of a negative number doesn't exist.");
        }    
        
            
    }
}*/

    //Print Digits Right to Left

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        while (num > 0) {
            int dig = num % 10; 
            System.out.println(dig);
            num = num/10;
        }
        System.out.println();
    }
}*/

  // Count Digits
        
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        int count = 0;
        while(num>0) {
            num=num/10;
            count++;
        }
        System.out.println(count);
    }
}*/

   // Sum of Numbers Divisible by 3 or 5

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int s = scan.nextInt();
        int e = scan.nextInt();
        int sum = 0;
        for (int i = s; i <= e; i++) {
            if (i % 3 == 0 || i % 5 == 0) {
                sum += i;
            }
        }    
        System.out.print(sum);
        
    }
}*/

  //Harshad Number

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        int temp = num;
        int sum = 0;
        while (temp > 0) {
            int digit = temp % 10;  
            sum += digit;           
            temp /= 10;             
        }
        if (num % sum == 0) {
            System.out.println("Harshad Number");
        } else {
            System.out.println("Not a Harshad Number");
        }
    }
}*/

    // sum of Digits
    
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        while (num > 0) {
            int digit = num % 10; 
            sum = sum + digit;   
            num = num / 10;            
        }
        System.out.println(sum);
    }
}*/

   //perfect Number
   
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        for (int i = 1; i <= num / 2; i++) {
            if (num % i == 0) {
                sum = sum + i;
            }
        }
        if (sum == num) {
            System.out.println("Perfect Number");
        } else {
            System.out.println("Not Perfect Number");
        }
    }
}*/

  // prime Number
  
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int count = 0;
        for (int i = 1; i <= num; i++) {
            if (num % i == 0) {
                count++;
            }
        }
        if (count == 2) {
            System.out.println("Prime Number");
        } else {
            System.out.println("Not Prime Number");
        }
    }
}*/

   // perfct square

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sqrt = (int) Math.sqrt(num);
        if (sqrt * sqrt == num) {
            System.out.println("Perfect Square");
        } else {
            System.out.println("Not Perfect Square");
        }
    }
}*/

   // FibonacciSeries

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int first = 0, second = 1;
        for (int i = 1; i <= n; i++) {
            System.out.print(first + " ");
            int next = first + second;
            first = second;
            second = next;
        }
    }
}*/







































