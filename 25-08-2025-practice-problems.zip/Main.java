  //day 1
  
  /*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kbd=new Scanner(System.in);
	    int year=kbd.nextInt();
        if(year%400==0 || year%100!=0&&year%4==0)
        System.out.println("leap year");
        else
        System.out.println("non leap year");
	}
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner kbd=new Scanner(System.in);
	    char choice=kbd.next().charAt(0);
        switch(choice){
            case 'A': System.out.println("Withdraw"); break;
            case 'B': System.out.println("Deposit"); break;
            case 'C': System.out.println("Balance Check"); break;
            default: System.out.println("Thank you please enter A-C");
        }
        
	}
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for(int i=1;i<=n;i++)
        System.out.print(i+" ");  
	}
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for(int i=10;i>=n;i--)
        System.out.print(i+" ");  
	}
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int i=n;
        while(i>=1)
        {        System.out.print(i+" ");
                    i--;  
                    System.out.println("A");
        }
    }
}*/ 

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	     Scanner scan = new Scanner(System.in);
        for(char i='A';i<='Z';i++)
        System.out.print(i+" ");
    }
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        for(char i='Z';i>='A'; i--)
        System.out.print(i+" ");
    }
}*/

/*import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for( int i=1;i<=n;i++){
        for( int j=1;j<=n;j++)
        System.out.print("*");
        System.out.println();
        }
    }
}*/

