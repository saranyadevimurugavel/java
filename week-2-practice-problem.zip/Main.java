   // left to right

/*import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int temp=n;
        int count=0;
        while(n>0){
            n=n/10;
            count++;
        }
            int num=(int)Math.pow(10,count-1);
      while(num>0){
          int dig=(temp/num)%10;
          System.out.print(dig+" ");
          num=num/10;
      }
	}
}*/

   // right to left
   
/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        while (num > 0) {
            int dig = num % 10; 
            System.out.print(dig+ " ");
            num = num/10;
        }
        System.out.println();
    }
}*/

   // Armstrong Number 

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        int original = number;
        int digits = String.valueOf(number).length();
        int temp = number, sum = 0;
        while (temp > 0) {
            int digit = temp % 10;
            sum += (int)Math.pow(digit, digits);
            temp /= 10;
        }
        if (sum == original) {
            System.out.println("Armstrong Number");
        } else {
            System.out.println("Not Armstrong Number");
        }
    }
}*/

  //Collatz Sequence 

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        while (num != 1) {
            System.out.print(num + ", ");
            if (num % 2 == 0) {
                num = num / 2;   
            } else {
                num = 3 * num + 1;  
            }
        }
        System.out.println(num);
    }
}*/

   // SpyNumber

/*import java.util.Scanner;
public class Main  {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        int prod = 1;
        while (num > 0) {
            int digit =  num % 10;   
            sum = sum + digit;            
            prod = prod * digit;        
            num /= 10;              
        }
        if (sum == prod) {
            System.out.println("Spy Number");
        } else {
            System.out.println("Not Spy Number");
        }
    }
}*/

  // NeonNumber

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int squ = num * num;
        int sum = 0;
        while (squ > 0) {
            sum = sum + squ % 10;   
            squ = squ / 10;        
        }
        if (sum == num) {
            System.out.println("Neon Number");
        } else {
            System.out.println("Not Neon Number");
        }
    }
}*/

    // PalindromeNumber

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int orgNum = num;
        int revNum = 0;
        while (num != 0) {
            int digit = num % 10;       
            revNum = revNum * 10 + digit; 
            num = num / 10;             
        }
        if (orgNum == revNum) {
            System.out.println("Palindrome");
        } else {
            System.out.println("Not Palindrome");
        }
    }
}*/

    // StrongNumber

/*import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int orgNum = num;
        int sum = 0;
        while (num > 0) {
            int digit = num % 10;
            int fact = 1;
            for (int i = 1; i <= digit; i++) {
                fact *= i;
            }
            sum = sum + fact;
            num = num / 10;
        }
        if (sum == orgNum) {
            System.out.println("Strong Number");
        } else {
            System.out.println("Not Strong Number");
        }
    }
}*/

   // MagicNumber

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = num;
        while (sum > 9) {
            int temp = sum;
            sum = 0;
            while (temp > 0) {
                sum = sum + temp % 10;
                temp = temp / 10;
            }
        }
        if (sum == 1) {
            System.out.println("Magic Number");
        } else {
            System.out.println("Not Magic Number");
        }
    }
}*/

   // CenterDigit

/*import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = sc.next(); 
        int length = num.length();
        if (length % 2 == 1) {
            int midIndex = length / 2;
            char center = num.charAt(midIndex);
            System.out.println(center);
        } else {
            System.out.println(-1);
        }
    }
}*/

   // DigitFrequency

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = sc.next();
        int[] freq = new int[10]; 
        for (int i = 0; i < num.length(); i++) {
            char ch = num.charAt(i);
            int digit = ch - '0';   
            freq[digit]++;
        }
        for (int i = 0; i < 10; i++) {
            if (freq[i] > 0) {
                System.out.println(i + " → " + freq[i]);
            }
        }
    }
}*/

   // SwapFirstLastDigit

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int temp = num;
        int digits = 0;
        while (temp > 0) {
            digits++;
            temp /= 10;
        }
        if (digits == 1) {
            System.out.println("Swapped Number: " + num);
            return;
        }
        int power = (int)Math.pow(10, digits - 1);
        int first = num / power;          
        int last = num % 10;              
        int middle = (num % power) / 10;  
        int swapped = last * power + middle * 10 + first;
        System.out.println("Swapped Number: " + swapped);
    }
}*/

   // ProductOfDigits

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int prod = 1;
        while (num > 0) {
            int digit = num % 10;   
            prod = prod * digit;
            num = num / 10;         
        }
        System.out.println( prod);
    }
}*/

   // SumOfEvenDigits 

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        while (num > 0) {
            int digit = num % 10; 
            if (digit % 2 == 0) {  
                sum = sum + digit;
            }
            num = num / 10;  
        }
        System.out.println(sum);
    }
}*/
   
   //  GCD Euclidean

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        while (b != 0) {
            int temp = b;
            b = a % b;  
            a = temp;
        }
        System.out.println(a);
    }
}*/













































































